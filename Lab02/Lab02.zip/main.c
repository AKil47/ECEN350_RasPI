extern long long int test();
// extern void lab02c(long long int a);
extern long long int lab02d (long long int a);


int main(void)
{
	test();
	//lab02c(21);
	lab02d(21);
    return 0;
}
